function GameChoiceInit()
	
end

function GameChoiceFrameMove()
	
end

function GameChoiceRender()
	
end